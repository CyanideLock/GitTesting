/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gittesting;

/**
 *
 * @author b.houston
 */
public class GitTesting {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Not so world");
        System.out.println("It is very different");
    }
    
}
